const API_BASE = "http://127.0.0.1:8000";

// Cards
const authCard = document.getElementById("authCard");
const appCard = document.getElementById("appCard");
const optimizerCard = document.getElementById("optimizerCard");
const mapCard = document.getElementById("mapCard");
const historyCard = document.getElementById("historyCard");

// Auth
const loginForm = document.getElementById("loginForm");
const registerForm = document.getElementById("registerForm");
const authMessage = document.getElementById("authMessage");
const showLoginBtn = document.getElementById("showLoginBtn");
const showRegisterBtn = document.getElementById("showRegisterBtn");
const logoutBtn = document.getElementById("logoutBtn");
const welcomeText = document.getElementById("welcomeText");

// Optimizer
const interchangeCostInput = document.getElementById("interchangeCost");
const roadCostInput = document.getElementById("roadCost");
const lambdaValueInput = document.getElementById("lambdaValue");
const cityNameInput = document.getElementById("cityName");
const cityXInput = document.getElementById("cityX");
const cityYInput = document.getElementById("cityY");
const cityWeightInput = document.getElementById("cityWeight");
const addCityBtn = document.getElementById("addCityBtn");
const clearCitiesBtn = document.getElementById("clearCitiesBtn");
const sampleCitiesBtn = document.getElementById("sampleCitiesBtn");
const optimizeBtn = document.getElementById("optimizeBtn");
const optimizerMessage = document.getElementById("optimizerMessage");
const cityListBox = document.getElementById("cityList");
const optimizerSummary = document.getElementById("optimizerSummary");
const resultBox = document.getElementById("resultBox");

// Map + history
const fitMapBtn = document.getElementById("fitMapBtn");
const refreshHistoryBtn = document.getElementById("refreshHistoryBtn");
const historyList = document.getElementById("historyList");

let cities = [];
let historyRuns = [];
let map;
let mapLayers = [];
let clickMarker = null;

const CLUSTER_COLORS = [
  "#2563eb",
  "#f59e0b",
  "#16a34a",
  "#dc2626",
  "#7c3aed",
  "#0891b2"
];

// ---------- Helpers ----------

function getToken() {
  return localStorage.getItem("token") || "";
}

function getUsername() {
  return localStorage.getItem("username") || "User";
}

function setText(element, text, color = "") {
  element.textContent = text;
  element.style.color = color;
}

function handleUnauthorized() {
  localStorage.removeItem("token");
  localStorage.removeItem("username");
  setText(authMessage, "Session expired. Please login again.", "red");
  setLoginState(false);
  showLoginTab();
}

function safeJsonParse(value, fallback = null) {
  try {
    return JSON.parse(value);
  } catch {
    return fallback;
  }
}

function round2(value) {
  return Math.round(value * 100) / 100;
}

// ---------- Login state ----------

function setLoginState(isLoggedIn) {
  if (isLoggedIn) {
    authCard.style.display = "none";
    appCard.style.display = "block";
    optimizerCard.style.display = "block";
    mapCard.style.display = "block";
    historyCard.style.display = "block";
    welcomeText.textContent = `Welcome, ${getUsername()}`;
    renderCities();
    initMap();
    setTimeout(() => map.invalidateSize(), 100);
    loadHistory();
  } else {
    authCard.style.display = "block";
    appCard.style.display = "none";
    optimizerCard.style.display = "none";
    mapCard.style.display = "none";
    historyCard.style.display = "none";
  }
}

function showLoginTab() {
  loginForm.style.display = "flex";
  registerForm.style.display = "none";
  showLoginBtn.classList.add("active");
  showRegisterBtn.classList.remove("active");
  setText(authMessage, "");
}

function showRegisterTab() {
  loginForm.style.display = "none";
  registerForm.style.display = "flex";
  showRegisterBtn.classList.add("active");
  showLoginBtn.classList.remove("active");
  setText(authMessage, "");
}

showLoginBtn.addEventListener("click", showLoginTab);
showRegisterBtn.addEventListener("click", showRegisterTab);

// ---------- Auth ----------

registerForm.addEventListener("submit", async (e) => {
  e.preventDefault();

  const user = {
    username: document.getElementById("registerUsername").value.trim(),
    email: document.getElementById("registerEmail").value.trim(),
    password: document.getElementById("registerPassword").value.trim()
  };

  try {
    const res = await fetch(`${API_BASE}/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(user)
    });

    const data = await res.json();

    if (!res.ok) {
      setText(authMessage, data.detail || "Registration failed", "red");
      return;
    }

    registerForm.reset();
    setText(authMessage, "Registration successful. Please login.", "green");
    showLoginTab();
  } catch (err) {
    setText(authMessage, "Cannot connect to backend", "red");
    console.error(err);
  }
});

loginForm.addEventListener("submit", async (e) => {
  e.preventDefault();

  const user = {
    email: document.getElementById("loginEmail").value.trim(),
    password: document.getElementById("loginPassword").value.trim()
  };

  try {
    const res = await fetch(`${API_BASE}/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(user)
    });

    const data = await res.json();

    if (!res.ok) {
      setText(authMessage, data.detail || "Login failed", "red");
      return;
    }

    localStorage.setItem("token", data.access_token);
    localStorage.setItem("username", user.email);
    loginForm.reset();
    setText(authMessage, "Login successful", "green");
    setLoginState(true);
  } catch (err) {
    setText(authMessage, "Cannot connect to backend", "red");
    console.error(err);
  }
});

logoutBtn.addEventListener("click", () => {
  localStorage.removeItem("token");
  localStorage.removeItem("username");
  setLoginState(false);
  clearOptimizerUI();
  clearMap();
});

// ---------- Optimizer ----------

function clearOptimizerUI() {
  setText(optimizerMessage, "");
  optimizerSummary.innerHTML = "";
  resultBox.textContent = "";
}

function resetCityInputs() {
  cityNameInput.value = "";
  cityXInput.value = "";
  cityYInput.value = "";
  cityWeightInput.value = "";
}

function renderCities() {
  cityListBox.innerHTML = "";

  if (cities.length === 0) {
    cityListBox.innerHTML = `<div class="empty-box">No cities added yet.</div>`;
    return;
  }

  cities.forEach((city, index) => {
    const div = document.createElement("div");
    div.className = "student-item";
    div.innerHTML = `
      <div class="student-row"><span class="label">Name:</span> ${city.name}</div>
      <div class="student-row"><span class="label">Coordinates:</span> (${city.x}, ${city.y})</div>
      <div class="student-row"><span class="label">Weight:</span> ${city.weight}</div>
      <div class="actions">
        <button type="button" class="delete-btn" onclick="removeCity(${index})">Remove</button>
      </div>
    `;
    cityListBox.appendChild(div);
  });
}

function addCity() {
  const name = cityNameInput.value.trim();
  const x = parseFloat(cityXInput.value);
  const y = parseFloat(cityYInput.value);
  const weight = parseFloat(cityWeightInput.value);

  if (!name || Number.isNaN(x) || Number.isNaN(y) || Number.isNaN(weight)) {
    setText(optimizerMessage, "Please fill all city fields correctly.", "red");
    return;
  }

  cities.push({ name, x, y, weight });
  resetCityInputs();
  renderCities();
  setText(optimizerMessage, "City added.", "green");
}

function removeCity(index) {
  cities.splice(index, 1);
  renderCities();
}

function loadSampleCities() {
  cities = [
    { name: "A", x: 10, y: 20, weight: 5 },
    { name: "B", x: 50, y: 80, weight: 10 },
    { name: "C", x: 90, y: 40, weight: 3 },
    { name: "D", x: 130, y: 100, weight: 8 },
    { name: "E", x: 25, y: 90, weight: 6 },
    { name: "F", x: 115, y: 35, weight: 4 }
  ];
  renderCities();
  setText(optimizerMessage, "Sample cities loaded.", "green");
}

function showOptimizationSummary(data, citySet = cities) {
  const clusterLegend = buildClusterLegend(citySet, data);

  optimizerSummary.innerHTML = `
    <div class="student-item">
      <div class="student-row"><span class="label">Strategy:</span> ${data.strategy}</div>
      <div class="student-row"><span class="label">Hub:</span> (${data.hub.x}, ${data.hub.y})</div>
      <div class="student-row"><span class="label">Road Length:</span> ${data.road_length}</div>
      <div class="student-row"><span class="label">Construction Cost:</span> ${data.construction_cost}</div>
      <div class="student-row"><span class="label">Travel Cost:</span> ${data.travel_cost}</div>
      <div class="student-row"><span class="label">System Score:</span> ${data.system_score}</div>
      ${clusterLegend}
    </div>
  `;
}

async function runOptimization() {
  const token = getToken();
  const X = parseFloat(interchangeCostInput.value);
  const Y = parseFloat(roadCostInput.value);
  const lambda_value = parseFloat(lambdaValueInput.value);

  if (Number.isNaN(X) || Number.isNaN(Y) || Number.isNaN(lambda_value)) {
    setText(optimizerMessage, "Please enter valid X, Y, and lambda values.", "red");
    return;
  }

  if (cities.length < 2) {
    setText(optimizerMessage, "Add at least 2 cities before optimizing.", "red");
    return;
  }

  try {
    setText(optimizerMessage, "Running optimization...", "#2563eb");

    const res = await fetch(`${API_BASE}/optimize`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${getToken()}`
      },
      body: JSON.stringify({
        X,
        Y,
        lambda_value,
        cities
      })
    });

    const data = await res.json();

    if (res.status === 401) {
      handleUnauthorized();
      return;
    }

    if (!res.ok) {
      setText(optimizerMessage, data.detail || "Optimization failed.", "red");
      return;
    }

    setText(optimizerMessage, "Optimization completed successfully.", "green");
    showOptimizationSummary(data, cities);
    resultBox.textContent = JSON.stringify(data, null, 2);
    drawLeafletNetwork(cities, data);
    loadHistory();
  } catch (err) {
    setText(optimizerMessage, "Cannot connect to backend.", "red");
    console.error(err);
  }
}

// ---------- Leaflet map ----------

function initMap() {
  if (map) return;

  map = L.map("leafletMap").setView([20, 78], 4);

  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    attribution: "© OpenStreetMap contributors"
  }).addTo(map);

  map.on("click", (e) => {
    const x = round2(e.latlng.lng);
    const y = round2(e.latlng.lat);

    cityXInput.value = x;
    cityYInput.value = y;

    if (!clickMarker) {
      clickMarker = L.marker([y, x]).addTo(map);
    } else {
      clickMarker.setLatLng([y, x]);
    }

    clickMarker.bindPopup(`Selected point<br>X: ${x}<br>Y: ${y}`).openPopup();
    setText(optimizerMessage, `Map click selected coordinates X=${x}, Y=${y}`, "green");
  });
}

function clearMap() {
  if (!map) return;
  mapLayers.forEach(layer => map.removeLayer(layer));
  mapLayers = [];
  if (clickMarker) {
    map.removeLayer(clickMarker);
    clickMarker = null;
  }
}

function addLayer(layer) {
  mapLayers.push(layer);
  layer.addTo(map);
}

function assignClusters(citySet, interchanges) {
  if (!interchanges || interchanges.length === 0) {
    return citySet.map(() => 0);
  }

  return citySet.map((city) => {
    let bestIdx = 0;
    let bestDist = Infinity;

    interchanges.forEach((hub, idx) => {
      const dx = city.x - hub.x;
      const dy = city.y - hub.y;
      const dist = Math.sqrt(dx * dx + dy * dy);
      if (dist < bestDist) {
        bestDist = dist;
        bestIdx = idx;
      }
    });

    return bestIdx;
  });
}

function buildClusterLegend(citySet, result) {
  if (!result.interchanges || result.interchanges.length <= 1) {
    return "";
  }

  const clusterAssignments = assignClusters(citySet, result.interchanges);
  const used = [...new Set(clusterAssignments)];

  const chips = used.map((clusterIdx) => {
    const color = CLUSTER_COLORS[clusterIdx % CLUSTER_COLORS.length];
    return `
      <span class="cluster-chip">
        <span class="cluster-dot" style="background:${color};"></span>
        Cluster ${clusterIdx + 1}
      </span>
    `;
  }).join("");

  return `<div class="cluster-legend">${chips}</div>`;
}

function drawLeafletNetwork(citySet, result) {
  initMap();
  clearMap();

  const bounds = [];
  const clusterAssignments = assignClusters(citySet, result.interchanges || []);

  citySet.forEach((city, index) => {
    const clusterIdx = clusterAssignments[index] || 0;
    const color = CLUSTER_COLORS[clusterIdx % CLUSTER_COLORS.length];

    const marker = L.circleMarker([city.y, city.x], {
      radius: 7,
      color,
      fillColor: color,
      fillOpacity: 0.9,
      weight: 2
    }).bindPopup(
      `<strong>City:</strong> ${city.name}<br><strong>Weight:</strong> ${city.weight}<br><strong>Coordinates:</strong> (${city.x}, ${city.y})<br><strong>Cluster:</strong> ${clusterIdx + 1}`
    );
    addLayer(marker);
    bounds.push([city.y, city.x]);
  });

  (result.interchanges || []).forEach((hub, idx) => {
    const color = CLUSTER_COLORS[idx % CLUSTER_COLORS.length];
    const marker = L.circleMarker([hub.y, hub.x], {
      radius: 8,
      color: "#dc2626",
      fillColor: color,
      fillOpacity: 0.95,
      weight: 3
    }).bindPopup(
      `<strong>Interchange:</strong> ${hub.name}<br><strong>Coordinates:</strong> (${hub.x}, ${hub.y})`
    );
    addLayer(marker);
    bounds.push([hub.y, hub.x]);
  });

  (result.segments || []).forEach((segment) => {
    const line = L.polyline(
      [
        [segment.from_y, segment.from_x],
        [segment.to_y, segment.to_x]
      ],
      {
        color: "#16a34a",
        weight: 3
      }
    ).bindPopup(
      `<strong>${segment.from} → ${segment.to}</strong><br><strong>Length:</strong> ${segment.length}<br><strong>Cost:</strong> ${segment.cost}`
    );
    addLayer(line);
    bounds.push([segment.from_y, segment.from_x]);
    bounds.push([segment.to_y, segment.to_x]);
  });

  if (bounds.length > 0) {
    map.fitBounds(bounds, { padding: [30, 30] });
  }
}

fitMapBtn.addEventListener("click", () => {
  if (map) {
    map.invalidateSize();
  }
});

// ---------- History ----------

async function loadHistory() {
  try {
    const res = await fetch(`${API_BASE}/optimization-runs`, {
      headers: {
        "Authorization": `Bearer ${getToken()}`
      }
    });

    const data = await res.json();

    if (res.status === 401) {
      handleUnauthorized();
      return;
    }

    if (!Array.isArray(data)) {
      historyList.innerHTML = `<div class="empty-box">Failed to load history.</div>`;
      return;
    }

    historyRuns = data;
    renderHistory();
  } catch (err) {
    historyList.innerHTML = `<div class="empty-box">Failed to load history.</div>`;
    console.error(err);
  }
}

function renderHistory() {
  historyList.innerHTML = "";

  if (historyRuns.length === 0) {
    historyList.innerHTML = `<div class="empty-box">No optimization runs found yet.</div>`;
    return;
  }

  historyRuns.forEach(run => {
    const div = document.createElement("div");
    div.className = "timeline-item";
    div.innerHTML = `
      <div class="timeline-title">Run #${run.id} — ${run.strategy}</div>
      <div class="history-row"><span class="label">Road Length:</span> ${run.road_length}</div>
      <div class="history-row"><span class="label">Construction Cost:</span> ${run.construction_cost}</div>
      <div class="history-row"><span class="label">Travel Cost:</span> ${run.travel_cost}</div>
      <div class="history-row"><span class="label">System Score:</span> ${run.system_score}</div>
      <div class="history-actions">
        <button type="button" class="secondary-btn" onclick="reloadRun(${run.id})">Load on Screen</button>
      </div>
    `;
    historyList.appendChild(div);
  });
}

function reloadRun(runId) {
  const run = historyRuns.find(item => item.id === runId);
  if (!run) return;

  const inputData = safeJsonParse(run.input_json, {});
  const resultData = safeJsonParse(run.result_json, {});

  if (Array.isArray(inputData.cities)) {
    cities = inputData.cities;
    renderCities();
  }

  if (typeof inputData.X !== "undefined") interchangeCostInput.value = inputData.X;
  if (typeof inputData.Y !== "undefined") roadCostInput.value = inputData.Y;
  if (typeof inputData.lambda_value !== "undefined") lambdaValueInput.value = inputData.lambda_value;

  if (resultData && resultData.strategy) {
    showOptimizationSummary(resultData, cities);
    resultBox.textContent = JSON.stringify(resultData, null, 2);
    drawLeafletNetwork(cities, resultData);
    setText(optimizerMessage, `Loaded optimization run #${run.id}`, "green");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }
}

refreshHistoryBtn.addEventListener("click", loadHistory);

// ---------- Events ----------

addCityBtn.addEventListener("click", addCity);
clearCitiesBtn.addEventListener("click", () => {
  cities = [];
  renderCities();
  clearOptimizerUI();
  clearMap();
});
sampleCitiesBtn.addEventListener("click", loadSampleCities);
optimizeBtn.addEventListener("click", runOptimization);

// ---------- Init ----------

window.removeCity = removeCity;
window.reloadRun = reloadRun;

if (getToken()) {
  setLoginState(true);
} else {
  setLoginState(false);
  showLoginTab();
}

renderCities();
clearOptimizerUI();