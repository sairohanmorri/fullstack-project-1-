from pydantic import BaseModel, EmailStr, ConfigDict, Field


class UserRegister(BaseModel):
    username: str
    email: EmailStr
    password: str


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str


class CityInput(BaseModel):
    name: str
    x: float
    y: float
    weight: float


class OptimizeRequest(BaseModel):
    X: float
    Y: float
    lambda_value: float = 1.0
    cities: list[CityInput]


class PointResponse(BaseModel):
    x: float
    y: float


class SegmentResponse(BaseModel):
    from_name: str = Field(alias="from")
    to: str
    from_x: float
    from_y: float
    to_x: float
    to_y: float
    length: float
    cost: float

    model_config = ConfigDict(populate_by_name=True)


class InterchangeResponse(BaseModel):
    name: str
    x: float
    y: float


class OptimizeResponse(BaseModel):
    strategy: str
    hub: PointResponse
    interchanges: list[InterchangeResponse]
    segments: list[SegmentResponse]
    road_length: float
    construction_cost: float
    travel_cost: float
    system_score: float

class OptimizationRunResponse(BaseModel):
    id: int
    user_email: str
    strategy: str
    road_length: float
    construction_cost: float
    travel_cost: float
    system_score: float
    input_json: str
    result_json: str

    model_config = ConfigDict(from_attributes=True)