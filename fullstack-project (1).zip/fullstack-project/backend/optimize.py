from math import sqrt
from itertools import combinations


def euclidean(a, b):
    return sqrt((a["x"] - b["x"]) ** 2 + (a["y"] - b["y"]) ** 2)


def point_dict(x, y):
    return {"x": float(x), "y": float(y)}


def weighted_hub(cities):
    total_w = sum(city["weight"] for city in cities)
    if total_w == 0:
        return {"x": 0.0, "y": 0.0}

    hx = sum(city["x"] * city["weight"] for city in cities) / total_w
    hy = sum(city["y"] * city["weight"] for city in cities) / total_w
    return {"x": hx, "y": hy}


def cluster_hub(cluster):
    return weighted_hub(cluster)


def mst_segments(cities, Y):
    parent = list(range(len(cities)))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a, b):
        ra, rb = find(a), find(b)
        if ra == rb:
            return False
        parent[rb] = ra
        return True

    edges = []
    for i, j in combinations(range(len(cities)), 2):
        dist = euclidean(cities[i], cities[j])
        edges.append((dist, i, j))

    edges.sort()
    chosen = []
    total_length = 0.0

    for dist, i, j in edges:
        if union(i, j):
            chosen.append({
                "from": cities[i]["name"],
                "to": cities[j]["name"],
                "from_x": cities[i]["x"],
                "from_y": cities[i]["y"],
                "to_x": cities[j]["x"],
                "to_y": cities[j]["y"],
                "length": round(dist, 3),
                "cost": round(dist * Y, 3)
            })
            total_length += dist

    return chosen, total_length


def weighted_neighbor_score(city_a, city_b):
    d = euclidean(city_a, city_b)
    weight_factor = max(city_a["weight"] + city_b["weight"], 1e-9)
    return d / weight_factor


def weighted_mst_segments(cities, Y):
    parent = list(range(len(cities)))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a, b):
        ra, rb = find(a), find(b)
        if ra == rb:
            return False
        parent[rb] = ra
        return True

    edges = []
    for i, j in combinations(range(len(cities)), 2):
        physical_dist = euclidean(cities[i], cities[j])
        score = weighted_neighbor_score(cities[i], cities[j])
        edges.append((score, physical_dist, i, j))

    edges.sort()
    chosen = []
    total_length = 0.0

    for _, physical_dist, i, j in edges:
        if union(i, j):
            chosen.append({
                "from": cities[i]["name"],
                "to": cities[j]["name"],
                "from_x": cities[i]["x"],
                "from_y": cities[i]["y"],
                "to_x": cities[j]["x"],
                "to_y": cities[j]["y"],
                "length": round(physical_dist, 3),
                "cost": round(physical_dist * Y, 3)
            })
            total_length += physical_dist

    return chosen, total_length


def nearest_city_index(cities, hub):
    best_idx = 0
    best_dist = float("inf")
    for i, city in enumerate(cities):
        d = euclidean(city, hub)
        if d < best_dist:
            best_dist = d
            best_idx = i
    return best_idx


def hub_star_segments(cities, hub, X, Y):
    segments = []
    total_length = 0.0

    for city in cities:
        dist = euclidean(city, hub)
        segments.append({
            "from": "HUB",
            "to": city["name"],
            "from_x": round(hub["x"], 3),
            "from_y": round(hub["y"], 3),
            "to_x": city["x"],
            "to_y": city["y"],
            "length": round(dist, 3),
            "cost": round(dist * Y, 3)
        })
        total_length += dist

    construction_cost = total_length * Y + X
    travel_cost = sum(city["weight"] * euclidean(city, hub) for city in cities)

    return segments, total_length, construction_cost, travel_cost


def hub_attachment_segments(cities, hub, X, Y):
    mst_segs, mst_len = mst_segments(cities, Y)
    attach_idx = nearest_city_index(cities, hub)
    attach_city = cities[attach_idx]
    attach_len = euclidean(hub, attach_city)

    hub_seg = {
        "from": "HUB",
        "to": attach_city["name"],
        "from_x": round(hub["x"], 3),
        "from_y": round(hub["y"], 3),
        "to_x": attach_city["x"],
        "to_y": attach_city["y"],
        "length": round(attach_len, 3),
        "cost": round(attach_len * Y, 3)
    }

    total_length = mst_len + attach_len
    construction_cost = total_length * Y + X
    travel_cost = sum(city["weight"] * euclidean(city, hub) for city in cities)

    return [hub_seg] + mst_segs, total_length, construction_cost, travel_cost


def weighted_mst_solution(cities, hub, Y):
    segs, total_length = weighted_mst_segments(cities, Y)
    construction_cost = total_length * Y
    travel_cost = sum(city["weight"] * euclidean(city, hub) for city in cities)
    return segs, total_length, construction_cost, travel_cost


def kmeans_like_partition(cities, k, iterations=10):
    if k <= 0 or k > len(cities):
        return []

    # deterministic seeds: first, middle, last... spread by index
    seed_indices = sorted(set(int(i * (len(cities) - 1) / max(k - 1, 1)) for i in range(k)))
    centers = [point_dict(cities[i]["x"], cities[i]["y"]) for i in seed_indices]

    for _ in range(iterations):
        clusters = [[] for _ in range(k)]

        for city in cities:
            best_idx = 0
            best_dist = float("inf")
            for i, center in enumerate(centers):
                d = euclidean(city, center)
                if d < best_dist:
                    best_dist = d
                    best_idx = i
            clusters[best_idx].append(city)

        # avoid empty clusters by keeping old center
        new_centers = []
        for i in range(k):
            if clusters[i]:
                new_centers.append(cluster_hub(clusters[i]))
            else:
                new_centers.append(centers[i])

        centers = new_centers

    final_clusters = [[] for _ in range(k)]
    for city in cities:
        best_idx = 0
        best_dist = float("inf")
        for i, center in enumerate(centers):
            d = euclidean(city, center)
            if d < best_dist:
                best_dist = d
                best_idx = i
        final_clusters[best_idx].append(city)

    return final_clusters


def build_interchange_network(clusters, X, Y):
    """
    Build a network with:
    - one interchange per cluster
    - each city connected to its cluster interchange
    - interchanges connected together by MST
    """
    interchanges = []
    segments = []
    total_length = 0.0

    # create interchanges and connect cities to them
    for idx, cluster in enumerate(clusters, start=1):
        if not cluster:
            continue

        hub = cluster_hub(cluster)
        hub_name = f"HUB_{idx}"
        interchanges.append({
            "name": hub_name,
            "x": round(hub["x"], 3),
            "y": round(hub["y"], 3)
        })

        for city in cluster:
            d = euclidean(city, hub)
            segments.append({
                "from": hub_name,
                "to": city["name"],
                "from_x": round(hub["x"], 3),
                "from_y": round(hub["y"], 3),
                "to_x": city["x"],
                "to_y": city["y"],
                "length": round(d, 3),
                "cost": round(d * Y, 3)
            })
            total_length += d

    # connect interchanges with MST
    if len(interchanges) >= 2:
        parent = list(range(len(interchanges)))

        def find(x):
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x

        def union(a, b):
            ra, rb = find(a), find(b)
            if ra == rb:
                return False
            parent[rb] = ra
            return True

        edges = []
        for i, j in combinations(range(len(interchanges)), 2):
            a = interchanges[i]
            b = interchanges[j]
            d = euclidean(a, b)
            edges.append((d, i, j))

        edges.sort()

        for d, i, j in edges:
            if union(i, j):
                a = interchanges[i]
                b = interchanges[j]
                segments.append({
                    "from": a["name"],
                    "to": b["name"],
                    "from_x": a["x"],
                    "from_y": a["y"],
                    "to_x": b["x"],
                    "to_y": b["y"],
                    "length": round(d, 3),
                    "cost": round(d * Y, 3)
                })
                total_length += d

    construction_cost = total_length * Y + X * len(interchanges)

    travel_cost = 0.0
    for cluster, hub in zip([c for c in clusters if c], interchanges):
        hub_point = point_dict(hub["x"], hub["y"])
        for city in cluster:
            travel_cost += city["weight"] * euclidean(city, hub_point)

    return interchanges, segments, total_length, construction_cost, travel_cost


def choose_best_solution(candidates):
    best = None
    for candidate in candidates:
        if best is None or candidate["system_score"] < best["system_score"]:
            best = candidate
    return best


def optimize_network(X, Y, cities, lam=1.0):
    if len(cities) < 2:
        raise ValueError("At least 2 cities are required")

    global_hub = weighted_hub(cities)
    candidates = []

    # 1. MST
    mst_segs, mst_len = mst_segments(cities, Y)
    mst_cost = mst_len * Y
    mst_travel = sum(city["weight"] * euclidean(city, global_hub) for city in cities)
    candidates.append({
        "strategy": "mst",
        "hub": {"x": round(global_hub["x"], 3), "y": round(global_hub["y"], 3)},
        "interchanges": [],
        "segments": mst_segs,
        "road_length": round(mst_len, 3),
        "construction_cost": round(mst_cost, 3),
        "travel_cost": round(mst_travel, 3),
        "system_score": round(mst_cost + lam * mst_travel, 3)
    })

    # 2. Weighted MST
    wmst_segs, wmst_len, wmst_cost, wmst_travel = weighted_mst_solution(cities, global_hub, Y)
    candidates.append({
        "strategy": "weighted_mst",
        "hub": {"x": round(global_hub["x"], 3), "y": round(global_hub["y"], 3)},
        "interchanges": [],
        "segments": wmst_segs,
        "road_length": round(wmst_len, 3),
        "construction_cost": round(wmst_cost, 3),
        "travel_cost": round(wmst_travel, 3),
        "system_score": round(wmst_cost + lam * wmst_travel, 3)
    })

    # 3. Hub star
    star_segs, star_len, star_cost, star_travel = hub_star_segments(cities, global_hub, X, Y)
    candidates.append({
        "strategy": "hub_star",
        "hub": {"x": round(global_hub["x"], 3), "y": round(global_hub["y"], 3)},
        "interchanges": [{
            "name": "HUB",
            "x": round(global_hub["x"], 3),
            "y": round(global_hub["y"], 3)
        }],
        "segments": star_segs,
        "road_length": round(star_len, 3),
        "construction_cost": round(star_cost, 3),
        "travel_cost": round(star_travel, 3),
        "system_score": round(star_cost + lam * star_travel, 3)
    })

    # 4. Hub attachment
    attach_segs, attach_len, attach_cost, attach_travel = hub_attachment_segments(cities, global_hub, X, Y)
    candidates.append({
        "strategy": "hub_attachment",
        "hub": {"x": round(global_hub["x"], 3), "y": round(global_hub["y"], 3)},
        "interchanges": [{
            "name": "HUB",
            "x": round(global_hub["x"], 3),
            "y": round(global_hub["y"], 3)
        }],
        "segments": attach_segs,
        "road_length": round(attach_len, 3),
        "construction_cost": round(attach_cost, 3),
        "travel_cost": round(attach_travel, 3),
        "system_score": round(attach_cost + lam * attach_travel, 3)
    })

    # 5. Two interchanges
    if len(cities) >= 4:
        clusters2 = kmeans_like_partition(cities, 2)
        inter2, seg2, len2, cost2, travel2 = build_interchange_network(clusters2, X, Y)
        candidates.append({
            "strategy": "two_interchanges",
            "hub": {"x": round(global_hub["x"], 3), "y": round(global_hub["y"], 3)},
            "interchanges": inter2,
            "segments": seg2,
            "road_length": round(len2, 3),
            "construction_cost": round(cost2, 3),
            "travel_cost": round(travel2, 3),
            "system_score": round(cost2 + lam * travel2, 3)
        })

    # 6. Three interchanges
    if len(cities) >= 6:
        clusters3 = kmeans_like_partition(cities, 3)
        inter3, seg3, len3, cost3, travel3 = build_interchange_network(clusters3, X, Y)
        candidates.append({
            "strategy": "three_interchanges",
            "hub": {"x": round(global_hub["x"], 3), "y": round(global_hub["y"], 3)},
            "interchanges": inter3,
            "segments": seg3,
            "road_length": round(len3, 3),
            "construction_cost": round(cost3, 3),
            "travel_cost": round(travel3, 3),
            "system_score": round(cost3 + lam * travel3, 3)
        })

    return choose_best_solution(candidates)