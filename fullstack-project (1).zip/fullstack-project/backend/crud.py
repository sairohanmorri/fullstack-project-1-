from sqlalchemy.orm import Session
import models
import schemas
import json


# -------------------------
# USER FUNCTIONS
# -------------------------

def get_user_by_email(db: Session, email: str):
    return db.query(models.User).filter(models.User.email == email).first()


def get_user_by_username(db: Session, username: str):
    return db.query(models.User).filter(models.User.username == username).first()


def create_user(db: Session, user: schemas.UserRegister, hashed_password: str):
    db_user = models.User(
        username=user.username,
        email=user.email,
        hashed_password=hashed_password
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user


# -------------------------
# OPTIMIZATION HISTORY
# -------------------------

def create_optimization_run(db: Session, user_email: str, payload: dict, result: dict):

    db_run = models.OptimizationRun(
        user_email=user_email,
        strategy=result["strategy"],
        road_length=result["road_length"],
        construction_cost=result["construction_cost"],
        travel_cost=result["travel_cost"],
        system_score=result["system_score"],
        input_json=json.dumps(payload),
        result_json=json.dumps(result)
    )

    db.add(db_run)
    db.commit()
    db.refresh(db_run)

    return db_run


def get_optimization_runs_by_user(db: Session, user_email: str):

    return (
        db.query(models.OptimizationRun)
        .filter(models.OptimizationRun.user_email == user_email)
        .order_by(models.OptimizationRun.id.desc())
        .all()
    )