from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session
import json
from database import SessionLocal, engine
import models
import schemas
import crud
from auth import verify_password, create_access_token, verify_token
from optimize import optimize_network

models.Base.metadata.create_all(bind=engine)

app = FastAPI()
security = HTTPBearer()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security)
):
    token = credentials.credentials
    payload = verify_token(token)

    if not payload:
        raise HTTPException(status_code=401, detail="Invalid or expired token")

    return payload


@app.get("/")
def read_root():
    return {"message": "Highway Network Optimizer Backend Working"}

@app.post("/register")
def register(user: schemas.UserRegister, db: Session = Depends(get_db)):

    if crud.get_user_by_email(db, user.email):
        raise HTTPException(status_code=400, detail="Email already registered")

    if crud.get_user_by_username(db, user.username):
        raise HTTPException(status_code=400, detail="Username already taken")

    # hash password
    from auth import get_password_hash
    hashed_password = get_password_hash(user.password)

    created_user = crud.create_user(db, user, hashed_password)

    return {
        "message": "User registered successfully",
        "user_id": created_user.id,
        "username": created_user.username
    }


@app.post("/login", response_model=schemas.TokenResponse)
def login(user: schemas.UserLogin, db: Session = Depends(get_db)):
    db_user = crud.get_user_by_email(db, user.email)

    if not db_user or not verify_password(user.password, db_user.hashed_password):
        raise HTTPException(status_code=401, detail="Invalid email or password")

    token = create_access_token(
        {"sub": db_user.email, "username": db_user.username}
    )

    return {
        "access_token": token,
        "token_type": "bearer",
    }


@app.post("/optimize", response_model=schemas.OptimizeResponse)
def optimize_route(
    payload: schemas.OptimizeRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):
    if len(payload.cities) < 2:
        raise HTTPException(status_code=400, detail="At least 2 cities are required")

    try:
        cities = [
            {
                "name": city.name,
                "x": city.x,
                "y": city.y,
                "weight": city.weight,
            }
            for city in payload.cities
        ]

        result = optimize_network(
            X=payload.X,
            Y=payload.Y,
            cities=cities,
            lam=payload.lambda_value,
        )

        payload_dict = {
            "X": payload.X,
            "Y": payload.Y,
            "lambda_value": payload.lambda_value,
            "cities": cities,
        }

        crud.create_optimization_run(
            db=db,
            user_email=current_user["sub"],
            payload=payload_dict,
            result=result
        )

        return result

    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Optimization failed: {str(e)}")
    
@app.get("/optimization-runs", response_model=list[schemas.OptimizationRunResponse])
def get_optimization_runs(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):
    return crud.get_optimization_runs_by_user(db, current_user["sub"])   