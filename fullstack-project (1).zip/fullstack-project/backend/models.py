from sqlalchemy import Column, Integer, String, Float, Text, ForeignKey
from database import Base


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(100), unique=True, nullable=False)
    email = Column(String(100), unique=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)


class OptimizationRun(Base):
    __tablename__ = "optimization_runs"

    id = Column(Integer, primary_key=True, index=True)
    user_email = Column(String(100), nullable=False)
    strategy = Column(String(100), nullable=False)
    road_length = Column(Float, nullable=False)
    construction_cost = Column(Float, nullable=False)
    travel_cost = Column(Float, nullable=False)
    system_score = Column(Float, nullable=False)
    input_json = Column(Text, nullable=False)
    result_json = Column(Text, nullable=False)